# Renderer Definition

Описание celery задач сервиса renderer-service.
